<?php
/*
  A2J Author 7 * Justice * justicia * 正义 * công lý * 사법 * правосудие
  All Contents Copyright The Center for Computer-Assisted Legal Instruction
  07/06/2016 Save data posted from A2J Viewer
*/
?>
<HTML>
<HEAD>
<TITLE>setDataURL | A2J Viewer 7</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8"/>
</HEAD>

<BODY>
<h1>setDataURL | A2J Viewer 7</h1>
<ul>
  <li>At this point, data will be saved and we can continue with our non-A2J Viewer interaction.
  <li>Below is the value submitted via POST in variable AnswerKey.
</ul>
<hr>
<div style="margin:2em;"><?=htmlspecialchars ($_POST['AnswerKey'])?></div>

<cite>Justice * 正义 * công lý * 사법 * правосудие</cite>
</BODY>
</HTML>
